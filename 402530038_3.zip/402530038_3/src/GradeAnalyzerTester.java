import javax.swing.JOptionPane;

public class GradeAnalyzerTester 
{
	public static void main(String[] args)
	{
	String input;
	GradeAnalyzer ga = new GradeAnalyzer();
	while(true)
	{
		input = JOptionPane.showInputDialog(null);
				if( input.equalsIgnoreCase("q")||input.equalsIgnoreCase("Q"))
				{
					break;
				}
				try
				{
					ga.addGrade(Double.parseDouble(input));
				}
				catch(Exception e)
				{
					System.out.println("�Э��s��J");
				}
	}
	ga.analyzeGrades();
	System.out.println(ga);
	}
}
