public class EasterTester 
{
	public static void main(String[] args)
	{
		System.out.println(Easter.calculateEaster(2001));
		System.out.println(Easter.calculateEaster(2012));
	}

}
