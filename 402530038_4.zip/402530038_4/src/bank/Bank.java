package bank;

import java.util.HashMap;

public class Bank 
{
	HashMap<Integer,BankAccount>BankList=new HashMap<Integer,BankAccount>();
	
	void addAccount(int accountNumber,double initalBalanace)
	{
        if (initalBalanace <0)
            initalBalanace =0;
        BankList.put(accountNumber, new BankAccount(accountNumber,initalBalanace ));
    }
	
	void deposit(int accountNumber, double initialBalance)
	{
		BankAccount ac = (BankAccount)BankList.get(accountNumber);
		try
		{
			ac.deposit(initialBalance);
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
	
	void withdraw(int accountNumber, double initialBalance)
	{
		BankAccount ac = (BankAccount)BankList.get(accountNumber);
		try
		{
			ac.withdraw(initialBalance);
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
	
	double getBalance(int accountNumber)
	{
		BankAccount ac = (BankAccount)BankList.get(accountNumber);
		return ac.getBalance();
	}
	
	void suspendAccount(int accountNumber)
	{
		BankAccount ac = (BankAccount)BankList.get(accountNumber);
		ac.suspend();
	}
	
	void reOpenAccount(int accountNumber)
	{
		BankAccount ac = (BankAccount)BankList.get(accountNumber);
		ac.reOpen();;
	}
	
	void closeAccount(int accountNumber)
	{
		BankAccount ac = (BankAccount)BankList.get(accountNumber);
		ac.close();
	}
	
	String getAccountStatus(int accountNumber)
	{
		BankAccount ac = (BankAccount)BankList.get(accountNumber);
		return ac.state;
	}
	
	String summarizeAccountTransactions(int accountNumber)
	{
		StringBuffer sb = new StringBuffer();
		BankAccount ac = (BankAccount) BankList.get(accountNumber);
		sb.append("Account  #" + accountNumber + " transaction:\n\n");
	    sb.append(ac.getTransactions());
	    sb.append("End of transactions\n");
		return sb.toString();
	}
	
	String summarizeAllAccounts()
	{ 
		StringBuffer sb = new StringBuffer();
		sb.append("Account\tBalance\t#Transactions\tStatus\n");
	    for(BankAccount bank: BankList.values()) 
		{
		    sb.append(bank.accountNumber +"\t");
		    sb.append(bank.getBalance() +"\t");
		    sb.append(bank.retrieveNumberOfTransactions() +"\t\t");
		    sb.append(bank.state +"\n");
		}
		sb.append("End of Account Summary\n");
		return sb.toString();
	}
	
	
}
