package bank;
import java.util.ArrayList;

public class BankAccount {
	String state;
	int accountNumber;
	private double balance;
	private ArrayList<Double> TranscationList = null;

	public BankAccount() 
	{
		this(-1,-1);
	}
	
	public BankAccount(int anAccountNumber) 
	{
       this(anAccountNumber,0);
		
	}
	
	public BankAccount(int anAccountNumber, double initialBalance) 
	{
		this.state = "open";
		this.accountNumber = anAccountNumber;
		this.balance = initialBalance;
		this.TranscationList = new ArrayList<Double>();
	}
	
	void suspend()
	{
		this.state = "suspended";
	}
	
	void close()
	{
		this.state = "closed";
	}
	
	void reOpen()
	{
		this.state = "open";
	}
	
	private boolean isOpen() 
	{
		return this.state.equalsIgnoreCase("open") ;
	}
	
	 private boolean isSuspended() 
	{
		return this.state.equalsIgnoreCase("suspended");
	}
	
	private boolean isClosed()
	{
		return this.state.equalsIgnoreCase("closed");
	}
	
	private void addTransaction(double amount) 
	{
	  this.TranscationList.add(amount);
	}
	
	void deposit(double amount) throws Exception
	{
	     if(!this.isOpen() || amount < 0) 
	     { 
	         throw new Exception("transction" + this.accountNumber + "deposit error");
	     }
	     this.balance += amount;
	     addTransaction (amount);
	}
	void withdraw(double amount) throws Exception 
	{
	     if(!this.isOpen() || amount < 0 || this.balance < amount) 
	     {
	         throw new Exception("transction:" + this.accountNumber + "withdraw error");
	     }    
	     this.balance -= amount;
	     addTransaction(0 - amount);
	}

	
	String getTransactions() 
	{
		StringBuffer sb = new StringBuffer();
	       for (int i = 0; i < this.TranscationList.size(); i++) 
	       {
	            sb.append((i + 1) +":"+ this.TranscationList.get(i) + "\n");
	       }
	       return sb.toString();	
	}
	
	double getBalance()
	{
		return this.balance;
	}
	
	int retrieveNumberOfTransactions() 
	{
		return this.TranscationList.size();
	}
}
